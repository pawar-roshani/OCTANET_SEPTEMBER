// script.js
document.querySelector('.btn').addEventListener('click', function () {
    alert('Button Clicked!');
});
